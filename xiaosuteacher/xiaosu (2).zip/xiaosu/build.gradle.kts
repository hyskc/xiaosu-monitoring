// 项目级构建脚本，只包含通用配置和插件
plugins {
    // 使用Version Catalog管理插件版本
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
}

// 所有子项目/模块的通用配置
subprojects {
    // 可以在这里添加适用于所有模块的配置
}

// 项目级依赖已移至各模块中

// 添加根项目任务别名，重定向到app模块任务
tasks.register("assembleDebug") {
    dependsOn(":app:assembleDebug")
    description = "Assembles the debug build of the app module"
    group = "build"
}