/*
 Navicat Premium Data Transfer

 Source Server         : sukuncan
 Source Server Type    : MySQL
 Source Server Version : 50742
 Source Host           : localhost:3306
 Source Schema         : xiaosudb

 Target Server Type    : MySQL
 Target Server Version : 50742
 File Encoding         : 65001

 Date: 02/03/2026 16:45:00
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for app_usage
-- ----------------------------
DROP TABLE IF EXISTS `app_usage`;
CREATE TABLE `app_usage`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `last_used` datetime(6) NULL DEFAULT NULL,
  `package_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `reported_at` datetime(6) NULL DEFAULT NULL,
  `usage_time` bigint(20) NOT NULL,
  `student_id` int(11) NOT NULL,
  `last_time_used` bigint(20) NULL DEFAULT NULL,
  `record_date` datetime(6) NOT NULL,
  `usage_time_millis` bigint(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK8jq9cqrj811xcvlei82kcve2e`(`student_id`) USING BTREE,
  CONSTRAINT `FK8jq9cqrj811xcvlei82kcve2e` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of app_usage
-- ----------------------------

-- ----------------------------
-- Table structure for association
-- ----------------------------
DROP TABLE IF EXISTS `association`;
CREATE TABLE `association`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) NOT NULL,
  `studentid` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_parent_id`(`parentid`) USING BTREE,
  INDEX `idx_student_id`(`studentid`) USING BTREE,
  CONSTRAINT `fk_parent_id` FOREIGN KEY (`parentid`) REFERENCES `parents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_student_id` FOREIGN KEY (`studentid`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of association
-- ----------------------------
INSERT INTO `association` VALUES (2, 1, 6);
INSERT INTO `association` VALUES (5, 1, 7);
INSERT INTO `association` VALUES (6, 1, 5);

-- ----------------------------
-- Table structure for parents
-- ----------------------------
DROP TABLE IF EXISTS `parents`;
CREATE TABLE `parents`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of parents
-- ----------------------------
INSERT INTO `parents` VALUES (1, 'sukuncan', '123456', '123456');

-- ----------------------------
-- Table structure for students
-- ----------------------------
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `unique_username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of students
-- ----------------------------
INSERT INTO `students` VALUES (1, '123456', '123456', 1);
INSERT INTO `students` VALUES (2, 'hongshayin', '123456', 0);
INSERT INTO `students` VALUES (3, 'sukuncan', '123456', 0);
INSERT INTO `students` VALUES (4, 'zyx', '123456', 0);
INSERT INTO `students` VALUES (5, 'zhang', '123456', 1);
INSERT INTO `students` VALUES (6, 'sukun', '123456', 1);
INSERT INTO `students` VALUES (7, 'ying', '123456', 0);
INSERT INTO `students` VALUES (8, 'zhangyingxuan', '123456', 0);
INSERT INTO `students` VALUES (9, 'susu', '123456', 0);
INSERT INTO `students` VALUES (10, 'sususu', '123456', 0);

SET FOREIGN_KEY_CHECKS = 1;
